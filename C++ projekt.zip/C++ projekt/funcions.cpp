#include <iostream>
#include <chrono>
#include <vector>
#include <functional>

void printAuthorName() {
        std::cout << "Meno autora: Andreas Nosál";
}

long long getCurrentTimeMillis() {
	return std::chrono::duration_cast<std::chrono::milliseconds>(
	std::chrono::system_clock::now().time_since_epoch()
	).count();
}

void bubbleSort(std::vector<int>& arr) {
	int n = arr.size();
	for (int i = 0; i < n - 1; ++i) {
		for (int j = 0; j < n - i - 1; ++j) {
			if (arr[j] > arr[j + 1]) {
				// Výmena hodnôt
				int temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}
}

void selectionSort(std::vector<int>& arr) {
	int n = arr.size();
	for (int i = 0; i < n - 1; ++i) {
		int minIndex = i;
			for (int j = i + 1; j < n; ++j) {
				if (arr[j] < arr[minIndex]) {
					minIndex = j;
				}
			}
		// Výmena hodnôt
		int temp = arr[minIndex];
		arr[minIndex] = arr[i];
		arr[i] = temp;
	}
}

void insertionSort(std::vector<int>& arr) {
	int n = arr.size();
		for (int i = 1; i < n; ++i) {
			int key = arr[i];
			int j = i - 1;

		while (j >= 0 && arr[j] > key) {
			arr[j + 1] = arr[j];
			--j;
		}
		arr[j + 1] = key;
	}
}

void printArray(const std::vector<int>& arr) {
	for (int num : arr) {
		std::cout << num << " ";
	}
	std::cout << std::endl;
}


int main() {
	std::vector<std::string> sortNames = {"Bubble", "Selection", "Insertion"};
	std::vector<std::function<void(std::vector<int>&)>> sortFunctions = {
        [](std::vector<int>& arr) { bubbleSort(arr); },
        [](std::vector<int>& arr) { selectionSort(arr); },
        [](std::vector<int>& arr) { insertionSort(arr); }
    };
	
	std::cout << "Aktuálny čas v milisekundách: " << getCurrentTimeMillis() << std::endl;
	std::cout << "\n---------------------------\n";
	std::vector<int> arr = {64, 34, 25, 12, 22, 11, 90};
	std::cout << "Pôvodné pole: ";
	printArray(arr);
	bubbleSort(arr);
	std::cout << "Zoradené pole do Bublle sort: ";
	printArray(arr);
	std::cout << "---------------------------\n";
	
	std::cout << "\n---------------------------\n";
	std::vector<int> arr2 = {64, 25, 12, 22, 11};
	std::cout << "Pôvodné pole: ";
	printArray(arr2);
	selectionSort(arr2);
	std::cout << "Zoradené pole do Selection sort: ";
	printArray(arr2);
	std::cout << "---------------------------\n";
	
	std::cout << "\n---------------------------\n";
	std::vector<int> arr3 = {61, 33, 53, 345, 3, 1, 55};
	std::cout << "Pôvodné pole: ";
	printArray(arr3);
	insertionSort(arr3);
	std::cout << "Zoradené pole do Insertion sort: ";
	printArray(arr3);
	std::cout << "---------------------------\n";
	
	for (int sort = 0; sort < sortNames.size(); sort++) {
		long long begginingTime = getCurrentTimeMillis();
		for (int repeat = 0; repeat < 100'001; repeat++) {
			std::vector<int> testArr = {82, 2, 5, 3, 1, 4, 7, 6, 9, 99};
			sortFunctions[sort](testArr);
		} 
		long long afterTime = getCurrentTimeMillis();
		long long timeComplexity = (afterTime - begginingTime);
		
		std::cout << sortNames[sort] <<" sort 100'000x krát spustený, trval:" << timeComplexity << "ms\n";
	}
	
	std::cout << "---------------------------\n";
	printAuthorName();
	return 0;
}
